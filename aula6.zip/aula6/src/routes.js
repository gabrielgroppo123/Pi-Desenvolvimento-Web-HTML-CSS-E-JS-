import express from 'express';
import obraController from './controller/obraController.js';
import clienteController from './controller/clienteController.js';
import emprestimoController from './controller/emprestimoController.js';
import loginController from './controller/loginController.js';

export default function adicionarRotas(api) {
  api.use(obraController);
  api.use(clienteController);
  api.use(emprestimoController);
  api.use(loginController);

  api.use('/public/storage/capa', express.static('public/storage/capa'))
}


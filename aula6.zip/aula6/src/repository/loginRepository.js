import connection from "./connection.js";

export async function criarConta(login) {
  const comando = `
    insert into login (email, senha)
    values (?, MD5(?));
  `;

  const [resposta] = await connection.query(comando, [
    login.email,
    login.senha
  ]);

  return resposta.insertId;
}

export async function login(email, senha) {
  let comando = `
    select id,
           email
      from login
     where email = ?
       and senha = MD5(?)
  `;

  const [linhas] = await connection.query(comando, [email, senha]);
  return linhas[0];
}


export async function buscarPorEmail(email) {
  const comando = `
    select * from login where email = ?
  `;

  const [linhas] = await connection.query(comando, [email]);
  return linhas[0];
}






import * as service from '../services/obraService.js';
import { Router } from 'express';
import multer from 'multer';
import { getAuthentication } from '../util/jwt.js';

const endpoints = Router();
const auth = getAuthentication();
const uploadCapa = multer({ dest: 'public/storage/capa' });

endpoints.post('/obras', auth, async (req, resp) => {
  let obra = req.body;

  let id = await service.adicionarObra(obra);

  resp.status(201).send({ id });
});

endpoints.get('/obras', auth,async (req, resp) => {
  let obras = await service.listarObras();
  resp.send(obras);
});

endpoints.get('/obras/:id', auth,async (req, resp) => {
  let id = Number(req.params.id);

  let obra = await service.buscarObraPorId(id);

  if (!obra) {
    resp.status(404).send({ erro: 'Obra não encontrada!' });
  } else {
    resp.send(obra);
  }
});

endpoints.put('/obras/:id', auth,async (req, resp) => {
  let id = Number(req.params.id);
  let obra = req.body;

  let linhas = await service.alterarObra(id, obra);

  if (linhas == 0) {
    resp.status(404).send({ erro: 'Obra não encontrada!' });
  } else {
    resp.send();
  }
});

endpoints.delete('/obras/:id', auth, async (req, resp) => {
  let id = Number(req.params.id);

  let linhas = await service.deletarObra(id);

  if (linhas == 0) {
    resp.status(404).send({ erro: 'Obra não encontrada!' });
  } else {
    resp.status(204).send();
  }
});


endpoints.put('/obras/:id/capa', uploadCapa.single('capa'), auth,async (req, resp) => {
  const id =  req.params.id;
  const caminho = req.file.path;

  const linhasAfetadas = await service.atualizarCapa(id, caminho);
  resp.send();
})

export default endpoints;
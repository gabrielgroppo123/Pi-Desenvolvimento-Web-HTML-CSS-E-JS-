package com.example.api.models.response;

public class DividirResponse {
    public Double resposta;

    public DividirResponse(Double r) {
        resposta = r;
    }
}

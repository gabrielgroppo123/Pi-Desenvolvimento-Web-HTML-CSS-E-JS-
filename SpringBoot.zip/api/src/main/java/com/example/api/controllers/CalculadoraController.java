package com.example.api.controllers;

import com.example.api.models.request.*;
import com.example.api.models.response.*;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/calculadora")
public class CalculadoraController {

    @GetMapping("/somar/{a}/{b}")
    public Integer somar(@PathVariable Integer a, @PathVariable Integer b) {
        return a + b;
    }

    @GetMapping("/subtrair")
    public Integer subtrair(@RequestParam Integer a, @RequestParam Integer b) {
        return a - b;
    }

    @PostMapping("/multiplicar")
    public Integer multiplicar(@RequestBody MultiplicarRequest dto) {
        return dto.a * dto.b;
    }

    @PostMapping("/media/{a}")
    public MediaResponse media(@PathVariable Double a, @RequestParam Double b, @RequestBody MediaRequest dto) {
        MediaResponse resp = new MediaResponse();
        resp.media = (a + b + dto.c) / 3;
        resp.situacao = resp.media >= 6 ? "Aprovado" : "DP";
        
        return resp;
    }

    @GetMapping("/dividir")
    public ResponseEntity<?> dividir(@RequestParam Double a, @RequestParam Double b) {
        if (b == 0) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body(new ErroResponse("Não é possível dividir por zero"));
        }
        return ResponseEntity.ok(new DividirResponse(a / b));
    }

}
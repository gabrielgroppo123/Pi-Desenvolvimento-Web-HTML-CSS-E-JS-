 package com.example.api.models.request;

 public class MultiplicarRequest {

    public int a;
    public int b;
}
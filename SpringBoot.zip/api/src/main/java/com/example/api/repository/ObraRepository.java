package com.example.api.repository;

import com.example.api.models.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ObraRepository extends JpaRepository<Obra, Integer> {
    Optional<Obra> findByTitulo(String titulo);

    List<Obra> findByTituloContainingAndEstoqueBetween(
        String titulo,
        Double estoqueMin,
        Double estoqueMax
    );
}

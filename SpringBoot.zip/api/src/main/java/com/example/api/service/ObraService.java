package com.example.api.service;

import com.example.api.models.entity.Obra;
import com.example.api.repository.ObraRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ObraService {

    @Autowired
    private ObraRepository repository;

    public Obra salvar(Obra produto) {
        var existente = repository.findByTitulo(produto.getTitulo());
        if (existente.isPresent()) {
            throw new RuntimeException("Produto já cadastrado");
        }
        return repository.save(produto);
    }

    public List<Obra> listar() {
        return repository.findAll();
    }

    public Optional<Obra> buscar(int id) {
        return repository.findById(id);
    }

    public Obra atualizar(Integer id, Obra produto) {
        produto.setId(id);
        return repository.save(produto);
    }

    public void deletar(int id) {
        repository.deleteById(id);
    }
}
package com.example.api.models.response;

public class MediaResponse {
    public Double media;
    public String situacao;
    
}
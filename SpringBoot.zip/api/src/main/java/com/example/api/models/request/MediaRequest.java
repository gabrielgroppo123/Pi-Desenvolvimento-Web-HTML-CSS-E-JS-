package com.example.api.models.request;

public class MediaRequest {
 
    public double c;
}

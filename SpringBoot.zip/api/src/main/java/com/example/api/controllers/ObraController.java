package com.example.api.controllers;

import com.example.api.models.entity.Obra;
import com.example.api.service.ObraService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/obra")
public class ObraController {

    @Autowired
    private ObraService service;

    @PostMapping
    public Obra salvar(@RequestBody Obra produto) {
        return service.salvar(produto);
    }

    @GetMapping
    public List<Obra> listar() {
        return service.listar();
    }

    @GetMapping("/{id}")
    public Optional<Obra> buscar(@PathVariable int id) {
        return service.buscar(id);
    }

    @PutMapping("/{id}")
    public Obra atualizar(@PathVariable int id, @RequestBody Obra produto) {
        return service.atualizar(id, produto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deletar(@PathVariable int id) {
        service.deletar(id);

        return ResponseEntity.ok().build();
    }
}
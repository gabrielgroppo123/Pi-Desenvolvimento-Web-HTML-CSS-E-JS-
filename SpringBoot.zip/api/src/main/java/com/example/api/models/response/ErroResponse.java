package com.example.api.models.response;

public class ErroResponse {
    public String erro;

    public ErroResponse(String e) {
        erro = e;
    }
}
